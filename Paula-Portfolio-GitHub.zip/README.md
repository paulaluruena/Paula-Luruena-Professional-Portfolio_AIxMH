# Paula Luruena Marquez — Professional Portfolio

A responsive portfolio grounded in Paula’s September 2026 CV, built for GitHub Pages. It includes selected experience, education, community involvement, contact links, and a two-page PDF résumé.

## Open the website

Open `index.html` in a browser. The website uses local fonts, artwork, and résumé assets. No account, API key, database, or paid service is needed.

## Publish with GitHub Pages

1. Open the existing public repository: `paulaluruena/Paula-Luruena-Professional-Portfolio`.
2. Keep `index.html` in the repository’s root and the `assets` folder intact. Do not move the website into a nested folder.
3. Open **Settings → Pages**. Set **Source** to **Deploy from a branch**, then select **main** and **/ (root)** and save.
4. Use the address shown by GitHub after the Pages deployment finishes. The expected address is `https://paulaluruena.github.io/Paula-Luruena-Professional-Portfolio/`; this README does not indicate that deployment has already occurred.

No build command or GitHub Actions configuration is required for this publishing method. The Vite setup is included only as a convenient local development environment.

GitHub’s official guide: https://docs.github.com/en/pages/quickstart

## Edit the portfolio

- `index.html`: biography, role descriptions, dates, education, contact information, and section order.
- `styles.css`: colors, typography, spacing, and responsive layouts.
- `script.js`: mobile navigation and copyright year.
- `assets/Paula-Luruena-Marquez-Resume.pdf`: downloadable résumé. Replace this file while keeping its name to update both download links.
- `assets/connection.webp`: original AI-generated decorative ribbon artwork. It is not a representation of Paula’s professional work.

To preview with live updates, run `npm ci` and `npm run dev`. The published site also works directly without a JavaScript framework. Core text and native expandable experience sections work without JavaScript; mobile menu behavior uses `script.js`.

## Content notes

Professional facts and dates are based on the supplied September 17, 2026 CV. The public résumé is edited for clarity and omits the street address and phone number. The duplicated Pi Beta Phi description under Psi Chi was removed; only the supplied Psi Chi membership is retained. AI and consumer-experience interests are labeled as future directions, not work experience or demonstrated technical qualifications. SLAM and French Studies are the minors listed in this CV; no additional minor has been claimed.

No client-identifying details, outcome statistics, invented projects, testimonials, or unverified social links are included.

## Assets and privacy

The site has no analytics, cookies, third-party scripts, or contact form. Its email link opens the visitor’s email application. Fonts are bundled locally; their SIL Open Font License notices are in `assets`. Portfolio text and generated artwork were prepared for Paula Luruena Marquez. The font licenses apply only to their respective fonts.
